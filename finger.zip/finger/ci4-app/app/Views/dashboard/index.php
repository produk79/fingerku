<?= $this->extend('layouts/app') ?>

<?= $this->section('content') ?>
<header class="topbar">
    <h1>Dashboard</h1>
    <div class="user-pill">
        <span><?= esc($user['name'] ?? 'User') ?></span>
        <span>(<?= esc($user['role'] ?? '-') ?>)</span>
    </div>
</header>

<section class="grid">
    <article class="card">
        <h3>Total Mesin</h3>
        <strong><?= esc((string) ($stats['devices'] ?? 0)) ?></strong>
    </article>
    <article class="card">
        <h3>Total User</h3>
        <strong><?= esc((string) ($stats['users'] ?? 0)) ?></strong>
    </article>
    <article class="card">
        <h3>Log Absensi</h3>
        <strong><?= esc((string) ($stats['attendance'] ?? 0)) ?></strong>
    </article>
    <article class="card">
        <h3>Mesin Online</h3>
        <strong><?= esc((string) ($stats['online'] ?? 0)) ?></strong>
    </article>
</section>

<section class="panel">
    <h2>Struktur CI4 Sudah Siap</h2>
    <p>
        Basis aplikasi sudah dipindah ke pola CI4: route terpusat, controller terpisah,
        filter autentikasi, layout reusable, dan asset CSS modular. Langkah berikutnya tinggal
        migrasi modul bisnis satu per satu dari server Node ke controller/model CI4.
    </p>
</section>
<?= $this->endSection() ?>
