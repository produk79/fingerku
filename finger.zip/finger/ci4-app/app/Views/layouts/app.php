<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'Dashboard') ?> | CSL Fingerprint</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/app.css') ?>">
</head>
<body class="app-page">
<div class="app-shell">
    <aside class="sidebar">
        <h2>CSL Fingerprint</h2>
        <p>CI4 structured app</p>
        <nav class="menu">
            <a class="active" href="<?= site_url('/dashboard') ?>">Dashboard</a>
            <a href="<?= site_url('/logout') ?>">Logout</a>
        </nav>
    </aside>

    <main class="main">
        <?= $this->renderSection('content') ?>
    </main>
</div>
</body>
</html>
