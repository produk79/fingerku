<?= $this->extend('layouts/auth') ?>

<?= $this->section('content') ?>
<section class="auth-card">
    <div class="auth-brand">
        <span class="brand-dot"></span>
        CSL Fingerprint
    </div>
    <h1 class="auth-title">Selamat datang kembali</h1>
    <p class="auth-subtitle">Masuk ke panel admin versi CI4 yang lebih rapi, bersih, dan terstruktur.</p>

    <?php if (!empty($error)): ?>
        <div class="alert"><?= esc($error) ?></div>
    <?php endif; ?>

    <form class="form-stack" method="post" action="<?= site_url('/login') ?>">
        <?= csrf_field() ?>
        <div class="field">
            <label for="username">Username</label>
            <input
                id="username"
                name="username"
                type="text"
                value="<?= old('username') ?>"
                autocomplete="username"
                required
                autofocus
            >
        </div>

        <div class="field">
            <label for="password">Password</label>
            <input
                id="password"
                name="password"
                type="password"
                autocomplete="current-password"
                required
            >
        </div>

        <button type="submit" class="btn-primary">Masuk</button>
    </form>

    <p class="auth-note">User default: <b>admin / 12345</b> dan <b>user / 12345</b>. Segera ganti untuk produksi.</p>
</section>
<?= $this->endSection() ?>
