<?php

namespace App\Libraries;

class AuthService
{
    private const SESSION_KEY = 'auth_user';

    private string $usersFile;

    public function __construct()
    {
        $this->usersFile = WRITEPATH . 'data' . DIRECTORY_SEPARATOR . 'users.json';
        $this->ensureDefaultUsers();
    }

    public function attempt(string $username, string $password): bool
    {
        $username = trim($username);

        if ($username === '' || $password === '') {
            return false;
        }

        $users = $this->loadUsers();
        foreach ($users as $user) {
            if (!isset($user['username'], $user['password_hash'])) {
                continue;
            }

            if ($user['username'] !== $username) {
                continue;
            }

            if (!password_verify($password, $user['password_hash'])) {
                return false;
            }

            session()->set(self::SESSION_KEY, [
                'id' => $user['id'] ?? null,
                'name' => $user['name'] ?? $user['username'],
                'username' => $user['username'],
                'role' => $user['role'] ?? 'user',
            ]);

            return true;
        }

        return false;
    }

    public function check(): bool
    {
        return session()->has(self::SESSION_KEY);
    }

    /**
     * @return array<string, mixed>|null
     */
    public function user(): ?array
    {
        $user = session()->get(self::SESSION_KEY);
        return is_array($user) ? $user : null;
    }

    public function logout(): void
    {
        session()->remove(self::SESSION_KEY);
        session()->regenerate(true);
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function loadUsers(): array
    {
        if (!is_file($this->usersFile)) {
            return [];
        }

        $raw = file_get_contents($this->usersFile);
        if ($raw === false || trim($raw) === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }

        return $decoded;
    }

    private function ensureDefaultUsers(): void
    {
        $dir = dirname($this->usersFile);
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        if (is_file($this->usersFile)) {
            return;
        }

        $seed = [
            [
                'id' => 'admin',
                'name' => 'Administrator',
                'username' => 'admin',
                'role' => 'admin',
                'password_hash' => password_hash('12345', PASSWORD_DEFAULT),
            ],
            [
                'id' => 'user',
                'name' => 'Operator',
                'username' => 'user',
                'role' => 'user',
                'password_hash' => password_hash('12345', PASSWORD_DEFAULT),
            ],
        ];

        file_put_contents($this->usersFile, json_encode($seed, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }
}
