<?php

namespace App\Controllers;

use App\Libraries\AuthService;

class DashboardController extends BaseController
{
    public function index(): string
    {
        $auth = new AuthService();

        return view('dashboard/index', [
            'title' => 'Dashboard',
            'user' => $auth->user(),
            'stats' => [
                'devices' => 0,
                'users' => 0,
                'attendance' => 0,
                'online' => 0,
            ],
        ]);
    }
}
