<?php

namespace App\Controllers;

use App\Libraries\AuthService;

class AuthController extends BaseController
{
    public function login()
    {
        $auth = new AuthService();
        if ($auth->check()) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login', [
            'title' => 'Login',
            'error' => session()->getFlashdata('error'),
        ]);
    }

    public function attemptLogin()
    {
        $username = (string) $this->request->getPost('username');
        $password = (string) $this->request->getPost('password');

        $auth = new AuthService();
        if ($auth->attempt($username, $password)) {
            return redirect()->to('/dashboard');
        }

        return redirect()->back()->withInput()->with('error', 'Username atau password salah.');
    }

    public function logout()
    {
        $auth = new AuthService();
        $auth->logout();

        return redirect()->to('/login');
    }
}
